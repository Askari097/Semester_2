<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah blog</title>
</head>
<body>
    <h2>tambah blog</h2>
    <form action="">
        nama : <input type="text">
        <button>Tambah</button>
    </form>
</body>
</html>